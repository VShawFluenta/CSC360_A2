Victoria Shaw'a submission for assignment 2, CSC 360. 
To compile and run this code, please type "make" into the command line.
This will compile the program into an executable called ACS. 
To run it, please type "./ACS <inputfilename.txt>" into the command line, with inputfilename as the name of a valid file with valid input in a valid format. 